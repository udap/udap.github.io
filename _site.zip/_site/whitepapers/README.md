UDAP Whitepapers
=========================
- Technical Whitepaper [EN]() | [CN](https://drive.google.com/file/d/1eo-7OVxk9bj3L1xHM1BCIM0u4Ql4JYpc/view?usp=sharing)

- Business Whitepaper [EN]() | [CN]()
