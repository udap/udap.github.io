$(function () {
  let arrList = [{
      coverImg: "./img/news/newcsdn.png",
      title: "BTA | LI ZHANG: Why do we need a universal blockchain asset platform?",
      content: "As a multi-chain architecture, there are many different applications in the UDAP platform.",
      url: "https://mp.weixin.qq.com/s?__biz=MzU2MTE1NDk2Mg==&mid=2247485134&idx=3&sn=056a25361e0f09dbaeec6b25fb8c667e&chksm=fc7c5833cb0bd125fa27064a6dff51b850484fbd74d96c16a4b40c6fef1643fa16e959b0cb9c&mpshare=1&scene=1&srcid=0516QmeXgH01OIcOKehqZi16&key=7282001dbf9a9df1d799cdd876534113aedd6778d6032ed8924aadb1a70a0f428a40031424e0227d2002931f81116743296f19203254d43cc56a64f023b2e2f2f6f1f54add1ea254d9d0fc86e6d25fb2&ascene=0&uin=MTE2MTY3MzcyMA%3D%3D&devicetype=iMac+MacBookAir7%2C2+OSX+OSX+10.12.6+build(16G1212)&version=12020810&nettype=WIFI&lang=zh_CN&fontScale=100&pass_ticket=O1zRRna8AOVr2TEJ309t7MJF%2BfKrNydp8I3evZLn9IeulRm53rPaU2Hfx1UF7a8q",
      date: "2018.4.6"
    },
    {
      coverImg: "./img/news/newlf.png",
      title: "Killer application has not yet appeared? UDAP wants to build a universal blockchain asset platform 丨TokenShow",
      content: "Compared with blockchain entrepreneurs, what UDAP Foundation LI ZHANG wants to do is different.",
      url: "https://www.leiphone.com/news/201804/Hid3zSqIqW6tBySy.html",
      date: "2018.4.20"
    },
    {
      coverImg: "./img/news/newsLogo.png",
      title: "UDAP：Life As Being Tokenized",
      content: "Record an interesting token travel",
      url: "http://m.cnncai.com/news/xinwen/34700.html",
      date: "2018.4.26"
    },
  ];

  var splicing = "";
  for (let i = 0; i < arrList.length; i++) {
    splicing =
      splicing +
      '<a href="' + arrList[i].url + '" target="_blank">' +
      '<div class="media new__wrap">' +
      '<div class="media-body news__content">' +
      '<div class="new__logo"><img class="media-object" src="' + arrList[i].coverImg + '" alt="..."></div>' +
      '<h4 class="media-heading">' +
      arrList[i].date +
      '</h4>' +
      '<p>' +
      arrList[i].content +
      '</p>' +
      '<p>' + arrList[i].title + '</p>' +
      '</div>' +
      '</div>' +
      '</a>';
  }
  $("#newsContent").html(splicing);


  function newPage() {
    let page_html = "";
    for (let i = 0; i < parseInt(arrList.length / 10); i++) {
      page_html =
        page_html +
        `
       <li class="on">1</li>
      `
    }
    $("#Page").html(page_html);
  }
  newPage();
})
///注释2018/05/16//老版样式
// ' <div class="media-left news__img">' +
// ' <a href="'+arrList[i].url +'" target="_blank">' +
// ' <img class="media-object" src="' + arrList[i].coverImg + '" alt="...">' +
// '</a>' +
// '</div>' +